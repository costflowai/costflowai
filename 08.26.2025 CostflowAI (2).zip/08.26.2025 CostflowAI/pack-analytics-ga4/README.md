# Analytics (GA4) Pack — CostFlowAI
Date: 2025-08-28

## Files
- `partials/analytics-ga4.html` — paste this snippet into the `<head>` of your layout or each page.
- `assets/js/calc-events.js` — include once site‑wide (end of `<body>`) to track calculator and contact events.

## Install
1) Add **Measurement ID** in `partials/analytics-ga4.html` (replace `G-XXXXXXXXXX` with your GA4 property ID).
2) In your HTML pages (ideally a shared layout), add:
   ```html
   <!-- HEAD -->
   <!--#include virtual="/partials/analytics-ga4.html" -->
   <!-- or paste the snippet directly into <head> -->

   <!-- BODY END -->
   <script src="/assets/js/calc-events.js" defer></script>
   ```
   If you don’t have server‑side includes, copy the snippet contents into your `<head>` manually.
3) Deploy. Verify events in GA4 → Admin → DebugView / Realtime.
