// CostFlowAI analytics events (GA4). Autodetects calculator pages and wires common buttons.
(function(){
  function whenReady(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function toolFromPath(p){
    if(p.includes('residential-rom-pro')) return 'residential-rom-pro';
    if(p.includes('residential-rom')) return 'residential-rom';
    if(p.includes('commercial-ti-pro')) return 'commercial-ti-pro';
    if(p.includes('commercial-ti')) return 'commercial-ti';
    if(p.includes('concrete-pro')) return 'concrete-pro';
    if(p.includes('concrete')) return 'concrete';
    if(p.includes('gc-general-conditions')) return 'gc-general-conditions';
    if(p.includes('cleanroom-fitout')) return 'cleanroom-fitout';
    return 'unknown';
  }
  function send(eventName, props){
    if(typeof gtag === 'function'){
      gtag('event', eventName, Object.assign({page_path: location.pathname}, props||{}));
    } else {
      console.warn('GA4 gtag() not found; event skipped', eventName, props);
    }
  }
  whenReady(function(){
    // Calculator events
    var tool = toolFromPath(location.pathname);
    var calcBtn = document.querySelector('#calc');
    if(calcBtn){ calcBtn.addEventListener('click', function(){ send('calc_run', {tool: tool}); }); }
    var csvBtn = document.querySelector('#csv');
    if(csvBtn){ csvBtn.addEventListener('click', function(){ send('csv_download', {tool: tool}); }); }
    // Contact form event
    var contact = document.querySelector('form[name="contact"]');
    if(contact){ contact.addEventListener('submit', function(){ send('contact_submit', {}); }); }
    // Outbound link tracking
    document.body.addEventListener('click', function(e){
      var a = e.target.closest('a[href^="http"]');
      if(a && a.host !== location.host){ send('outbound_click', {href:a.href}); }
    }, true);
  });
})();
